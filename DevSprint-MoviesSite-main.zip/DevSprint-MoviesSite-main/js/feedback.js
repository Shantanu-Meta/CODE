
// const fs = require('../feedback/fb.txt');


function storing() {
    let name = document.getElementById(na);
    let email =document.getElementById(ph);
    let phone =document.getElementById(em);
    let message =document.getElementById(text);
}
if(document.getElementById("submit")){
    // alert("responce submitted");
}
