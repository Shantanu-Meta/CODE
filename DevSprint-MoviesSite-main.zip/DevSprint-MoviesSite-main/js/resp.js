
burger = document.querySelector('.burger');
navbar = document.querySelector('.navbar');
navList = document.querySelector('.nav-list');
rightNav = document.querySelector('.rightNav');



burger.addEventListener('click', ()=>{
    rightNav.classList.toggle('v-class-resp');
    navList.classList.toggle('v-class-resp');
    navbar.classList.toggle('h-nav-resp');

})

function clickEvent(id){
    console.log(id);
    switch (id) {
        case "up":
            window.open('https://www.google.com/search?q=upcomming+movies');
            break;
        case "up1": // pathan
            window.open('https://www.imdb.com/title/tt12844910/');
            break;
        case "up2": //dunki
            window.open('https://www.imdb.com/title/tt15428134/');
            break;
        case "up3": // fighter
            window.open('https://www.google.com/search?q=top-rated+movies');
            break;
        case "up4":
            window.open('https://www.google.com/search?q=top-rated+movies');
        break;
        case "po":
            window.open('https://www.google.com/search?q=popular+movies');
            break;
        case "po1": //lal singh chada
            window.open('https://www.google.com/search?q=upcomming+movies');
            break;
        case "po2": // liger
            window.open('https://www.google.com/search?q=top-rated+movies');
            break;
        case "po3": //jaadugar
            window.open('https://www.google.com/search?q=top-rated+movies');
            break;
        case "po4": //bhool bhuliya 2
            window.open('https://www.google.com/search?q=top-rated+movies');
        break;
        case "tr":
            window.open('https://www.google.com/search?q=popular+movies');
            break;
        case "tr1": //
            window.open('https://www.google.com/search?q=upcomming+movies');
            break;
        case "tr2":
            window.open('https://www.google.com/search?q=top-rated+movies');
            break;
        case "tr3":
            window.open('https://www.google.com/search?q=top-rated+movies');
            break;
        case "tr4":
            window.open('https://www.google.com/search?q=top-rated+movies');
        break;
    }
}
